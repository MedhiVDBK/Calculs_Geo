package BE.AC.UMONS;

public class Surface {
    public static int surf(int a, int b) {
        return Produit.mult(a, b);
    }
}