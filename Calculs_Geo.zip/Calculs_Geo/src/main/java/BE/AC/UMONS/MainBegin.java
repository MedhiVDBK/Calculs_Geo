package BE.AC.UMONS;

public class MainBegin {
    public static void main(String args[]) {

        System.out.println("Addition (10,10) = " + Addition.add(10,10));

        System.out.println("Produit (6, 10) = " + Produit.mult(6,10));

        System.out.println("Surface (4, 6) =  " + Surface.surf(4,6));

        System.out.println("Perimetre (3, 2) = " + Perimetre.perim(3,2));
    }
}
