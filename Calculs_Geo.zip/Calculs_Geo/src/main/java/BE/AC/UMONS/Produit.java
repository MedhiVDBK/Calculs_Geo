package BE.AC.UMONS;


public class Produit {

    public static int mult(int a, int b) {
        return a*b;
    }
}
